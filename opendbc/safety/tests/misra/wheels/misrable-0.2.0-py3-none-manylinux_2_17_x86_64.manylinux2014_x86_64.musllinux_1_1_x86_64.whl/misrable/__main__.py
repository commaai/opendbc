import os
import subprocess
import sys
import tarfile

from misrable import find_misrable_bin

if __name__ == "__main__":
    binary = find_misrable_bin()
    if sys.platform == "win32":
        sys.exit(subprocess.call([binary, *sys.argv[1:]]))
    os.execvp(binary, [binary, *sys.argv[1:]])
