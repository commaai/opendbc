"""Locate the misrable executable installed by this wheel."""

import os
import sys
import tarfile
import sysconfig

__all__ = ["find_misrable_bin"]


def find_misrable_bin() -> str:
    exe = "misrable" + (".exe" if sys.platform == "win32" else "")
    candidates = [sysconfig.get_path("scripts")]
    if sys.version_info >= (3, 10):
        candidates.append(sysconfig.get_path("scripts", sysconfig.get_preferred_scheme("user")))
    for directory in candidates:
        path = os.path.join(directory, exe)
        if os.path.isfile(path):
            return path
    raise FileNotFoundError(exe)
